/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
const actionCreator = (action, payload) => {
  return {
    action,
    payload
  };
};
/**==============> Initializing ================>*/
// Add control panels and indicators


App.onJoinPlayer.Add(player => {
  player.tag = {
    topIndicator: player.showWidget("bottom-modal.html", "bottom", 500, 250),
    bottomModal: player.showWidget("top-indicator.html", "top", 300, 50)
  };
  player.storage = JSON.stringify({
    tileInfos: {},
    currentTileInfo: null
  });
  player.save();
});
/**<============== End Initializing <================*/

const between = (x, min, max) => x >= min && x <= max;

const getCurrentTile = storage => storage.tileInfos[storage.currentTileId]; // Add listeners for land tiles


const registerLandTileListener = ({
  id,
  range,
  crop,
  progress
}) => {
  // Add initial tile info to player storage
  App.onJoinPlayer.Add(player => {
    const storage = JSON.parse(player.storage);
    storage.tileInfos[id] = {
      id,
      range,
      crop,
      progress
    };
    player.storage = JSON.stringify(storage);
    player.save();
  }); // Update current tile info when player touches the tile

  App.onObjectTouched.Add((sender, x, y) => {
    const [xmin, xmax] = range.x;
    const [ymin, ymax] = range.y;

    if (between(x, xmin, xmax) && between(y, ymin, ymax)) {
      const storage = JSON.parse(sender.storage || "{}");
      storage.currentTileId = id;
      sender.storage = JSON.stringify(storage);
      sender.save();
      const tag = sender.tag;
      tag.bottomModal.sendMessage(actionCreator("update-current-tile-info", getCurrentTile(storage)));
      tag.topIndicator.sendMessage(actionCreator('update-current-tile-info', getCurrentTile(storage)));
    }
  });
};