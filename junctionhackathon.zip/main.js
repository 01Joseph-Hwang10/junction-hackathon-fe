/**
 * Copyright (c) 2022 ZEP Co., LTD
 */

/**==============> Initializing ================>*/
// Add control panels and indicators
App.onJoinPlayer.Add(player => {
  // Bottom Modal
  player.showWidget("bottom-modal.html", "bottom", 500, 250); // Top Indicator

  player.showWidget("top-indicator.html", "top", 300, 50);
  player.storage = JSON.stringify({
    tileInfos: {},
    assets: null
  });
  window.localStorage.setItem("CurrentTileInfo", "{}");
  player.save();
});
/**<============== End Initializing <================*/

const between = (x, min, max) => x >= min && x <= max; // Add listeners for land tiles


const registerLandTileListener = ({
  id,
  range,
  crop,
  progress
}) => {
  // Add initial tile info to player storage
  App.onJoinPlayer.Add(player => {
    const storage = JSON.parse(player.storage);
    storage.tileInfos[id] = {
      id,
      range,
      crop,
      progress
    };
    player.storage = JSON.stringify(storage);
    player.save();
  }); // Update current tile info when player touches the tile

  App.onObjectTouched.Add((sender, x, y, tileID) => {
    const [xmin, xmax] = range.x;
    const [ymin, ymax] = range.y;

    if (between(x, xmin, xmax) && between(y, ymin, ymax)) {
      const storage = JSON.parse(sender.storage || "{}");
      window.localStorage.setItem("CurrentTileInfo", JSON.stringify(storage.tileInfos[id]));
      window.dispatchEvent(new StorageEvent("storage", {
        key: "CurrentTileInfo"
      }));
    }
  });
};

const updateComponents = info => {// Do HTML manipulation
};

window.onstorage = e => {
  if (e.key === "CurrentTileInfo") {
    const info = JSON.parse(window.localStorage.getItem("CurrentTileInfo"));
    updateComponents(info);
  }
};